class LayingHen
  def initialize
  end

  # Ages the hen one month, and lays 4 eggs if the hen is older than 3 months
  def age!
    
  end  
end

class Egg

end
