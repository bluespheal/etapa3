require 'laying_hen'

describe LayingHen do
  # LayingHen tests here
end

describe Egg do
  # Egg tests here
end
